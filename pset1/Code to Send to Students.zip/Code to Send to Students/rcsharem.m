function [shares,jacob]=rcsharem(meanutility,mu,price,originalprice,theta1,theta2,alphai)
% Compute the Jacobian and the Share of the Random Coefficients Model for
% each market

% Add price effect to mean utility and take away original price
mval=meanutility+theta1(1).*price-theta1(1).*originalprice;

% Get individual Shares
indshare=ind_sh(mval,exp(mu));
indshare=reshape(indshare,20,24)';

jacobi=zeros(24,24,20);
% Compute New Jacobian for Random Coefficients model
for t=1:94
    for i=1:20
        jacobi(:,:,i)=alphai(i).*diag(indshare(:,i))-alphai(i).*indshare(:,i)'*indshare(:,i);   
    end
end
jacob=mean(jacobi,3);

% Give market Shares
shares=mktsh(mval, exp(mu));
