function focvalue=pricingfoc(price,alpha,meanutility,Ownership,mc)
% This function computes the optimal price (fixed point here)

% Generate Market Shares Given a price vector and derivatives with respect
% to price
[shares,jacob]=logitshare(meanutility,price,alpha);

% Compute Value of Objective Function 
invomega=inv(jacob.*Ownership);
focvalue=(invomega*shares-(price-mc))';
