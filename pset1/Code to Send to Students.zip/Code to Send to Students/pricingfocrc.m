function focvalue=pricingfocRC(price,market,originalprice,alphai,mvalue,mu,Ownership,mc,theta1,theta2)
% This function computes the first order condition for optimal price (fixed
% point here)

% Generate Market Shares Given a price vector and derivatives with respect
% to price
m=1:24;
m=m+(market-1)*24;
newprice=originalprice;
newprice(m)=price;
[shares,jacob]=rcshare(mvalue,mu,newprice,originalprice,theta1,theta2,alphai);
% This is coded quite poorly since we compute all prices for all markets
% while we are only interested in a single market

% Compute Value of Objective Function 
invomega=inv(-jacob(:,:,market).*Ownership);
focvalue=invomega*shares(m)'-price-mc(m)';
