function [shares,jacob]=rcshare(meanutility,mu,price,originalprice,theta1,theta2,alphai)
% Compute the Jacobian and the Share of the Random Coefficients Model for
% each market

% Add price effect to mean utility and take away original price
mval=meanutility+theta1(1).*price-theta1(1).*originalprice;

% Get individual Shares
indshare=ind_sh(mval,exp(mu));
indshare=reshape(indshare,94,20,24);
indshare=permute(indshare,[1 3 2]);
temp=mean(indshare,3);

jacobi=zeros(24,24,20,94);
% Compute New Jacobian for Random Coefficients model
for t=1:94
    for i=1:20
        jacobi(:,:,i,t)=alphai(t,i).*diag(indshare(t,:,i))-alphai(t,i).*indshare(t,:,i)'*indshare(t,:,i);   
    end
end
jacob=mean(jacobi,3);
jacob=reshape(jacob,24,24,94);

% Give market Shares
shares=reshape(mktsh(mval, exp(mu)),94,24);
